package com.saleh.nidaabot

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        layout.addView(TextView(this).apply {
            text = "نداء الجيوش Bot — نموذج أولي\n\nهذا ليس بوتًا مكتملًا بعد. لازم نضبط إحداثيات وخطوات اللعبة ونختبرها."
            textSize = 18f
        })
        layout.addView(Button(this).apply {
            text = "فتح إعدادات إمكانية الوصول"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        layout.addView(Button(this).apply {
            text = "جدولة تشغيل تجريبي بعد دقيقتين"
            setOnClickListener { scheduleTest() }
        })
        layout.addView(Button(this).apply {
            text = "إلغاء التشغيل المجدول"
            setOnClickListener {
                val pi = PendingIntent.getBroadcast(this@MainActivity, 1001,
                    Intent(this@MainActivity, RunReceiver::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
                Toast.makeText(this@MainActivity, "تم إلغاء الموعد التجريبي", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(layout)
    }

    private fun scheduleTest() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, RunReceiver::class.java)
        val pi = PendingIntent.getBroadcast(this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val at = System.currentTimeMillis() + 2 * 60 * 1000L
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarm.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName")))
                Toast.makeText(this, "اسمح بجدولة المنبهات ثم اضغط الجدولة مرة أخرى", Toast.LENGTH_LONG).show()
                return
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, at, pi)
            Toast.makeText(this, "تم جدولة اختبار بعد دقيقتين (ليس تشغيلًا فعليًا للعبة)", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "تعذرت الجدولة: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
