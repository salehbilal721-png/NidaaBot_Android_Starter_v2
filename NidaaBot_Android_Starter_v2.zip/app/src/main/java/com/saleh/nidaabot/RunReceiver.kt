package com.saleh.nidaabot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class RunReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Safe placeholder: do not tap the game until the sequence is calibrated and verified.
        Toast.makeText(context, "موعد الاختبار وصل. لم يتم لمس اللعبة لأن خطوات البوت لم تُعاير بعد.", Toast.LENGTH_LONG).show()
    }
}
